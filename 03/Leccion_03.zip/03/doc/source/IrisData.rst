IrisData package
================

Submodules
----------

IrisData.PyQt module
--------------------

.. automodule:: IrisData.PyQt
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: IrisData
   :members:
   :undoc-members:
   :show-inheritance:
